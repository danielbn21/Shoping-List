import { makeChains } from './chains.js';
import { createHttp } from './portals/http.js';
import { createPortals } from './portals/clients.js';
import { createDirectory } from './portals/directory.js';
import { createPrices } from './prices.js';
import { createAutoMatcher } from './automatch.js';
import { createSuggester } from './suggest.js';
import { createGuesser } from './guesses.js';
import { createAi } from './ai.js';
import { createCatalog } from './catalog.js';
import { createBarcodeLookup } from './barcode.js';
import compareRoutes from './compare.js';
import portalRoutes from './portalRoutes.js';

// This module's own database (data/modules/price-compare/data.db). Ids of lists and stores are plain numbers from the core;
// the module cleans up after itself when the core says a list, store or household is gone (see the events below).
export const migrations = [
  `
CREATE TABLE store_chain (            -- which supermarket chain a household store is
  store_id INTEGER PRIMARY KEY,
  chain TEXT NOT NULL
);
CREATE TABLE list_compare_stores (    -- the chains and branches each list compares
  id INTEGER PRIMARY KEY,
  list_id INTEGER NOT NULL,
  chain TEXT NOT NULL,
  branch_id TEXT NOT NULL DEFAULT '',
  branch_name TEXT,
  position INTEGER NOT NULL DEFAULT 0,
  UNIQUE (list_id, chain, branch_id)
);
CREATE TABLE list_compare_cities (
  list_id INTEGER NOT NULL,
  city_key TEXT NOT NULL,
  PRIMARY KEY (list_id, city_key)
);
CREATE TABLE portal_branches (        -- a shared (public) directory of branches read from each chain's Stores file
  chain TEXT NOT NULL,
  store_id TEXT NOT NULL,             -- without leading zeros
  name TEXT NOT NULL,
  address TEXT NOT NULL DEFAULT '',
  city_key TEXT NOT NULL DEFAULT '',  -- numeric locality code without leading zeros, or the city name when the file gives a name
  zip TEXT NOT NULL DEFAULT '',
  banner TEXT NOT NULL DEFAULT '',
  sub_chain TEXT NOT NULL DEFAULT '',
  store_type TEXT NOT NULL DEFAULT '',
  PRIMARY KEY (chain, store_id)
);
CREATE INDEX idx_portal_branches_city ON portal_branches(city_key);
CREATE TABLE portal_chain_state (
  chain TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 1,
  branches_fetched_at INTEGER,
  stores_file TEXT,
  branch_count INTEGER NOT NULL DEFAULT 0,
  last_ok_at INTEGER,
  last_error TEXT,
  last_error_at INTEGER
);
CREATE TABLE custom_chains (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  portal_user TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL
);
CREATE TABLE city_names (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  source TEXT NOT NULL                -- 'gov' (data.gov.il) or 'seed' (built-in fallback for the biggest cities)
);
CREATE TABLE portal_meta (
  key TEXT PRIMARY KEY,
  value TEXT
);
`,
  // 2 (1.1.0): branch prices, the confirmed product for each household item and chain
  `
CREATE TABLE branch_prices (          -- the latest known price of every product at every selected branch, merged from the daily files
  chain TEXT NOT NULL,
  store_id TEXT NOT NULL,
  code TEXT NOT NULL,                 -- ItemCode as in the file
  item_type INTEGER NOT NULL DEFAULT 1, -- 1 = barcode, 0 = the chain's own code
  name TEXT NOT NULL,
  name_norm TEXT NOT NULL,
  manufacturer TEXT NOT NULL DEFAULT '',
  price REAL NOT NULL,                -- per kilo when the product is weighed
  unit_price REAL,
  unit TEXT NOT NULL DEFAULT '',      -- what unit_price is per: kg, g, l, ml, item, m ('' when the file gives none)
  unit_per REAL NOT NULL DEFAULT 0,   -- ... per this many of them (100 g, 1 l)
  pack_amount REAL,                   -- pack size in g, ml, item or m
  pack_unit TEXT,
  weighted INTEGER NOT NULL DEFAULT 0,
  price_updated TEXT,
  seen_file TEXT NOT NULL,            -- stamp (yyyymmddhhmmss) of the newest file that listed the product
  PRIMARY KEY (chain, store_id, code)
);
CREATE INDEX idx_branch_prices_name ON branch_prices(chain, store_id, name_norm);
CREATE TABLE branch_price_state (
  chain TEXT NOT NULL,
  store_id TEXT NOT NULL,
  file TEXT,
  file_stamp TEXT,
  items INTEGER NOT NULL DEFAULT 0,
  checked_at INTEGER,                 -- last time the portal was asked (a newer file or not)
  updated_at INTEGER,                 -- last time prices were merged in
  error TEXT,
  error_at INTEGER,
  PRIMARY KEY (chain, store_id)
);
CREATE TABLE product_map (            -- the household's confirmation: this item is that product at this chain
  household_id INTEGER NOT NULL,
  item_id INTEGER NOT NULL,
  chain TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('confirmed', 'none')),  -- none = this chain does not sell it
  code TEXT,
  item_type INTEGER,
  name TEXT,
  amount_kg REAL,                     -- weighed products: how much "1" on the list means, in kilos
  confirmed_by INTEGER,
  confirmed_at INTEGER NOT NULL,
  PRIMARY KEY (household_id, item_id, chain)
);
CREATE INDEX idx_product_map_item ON product_map(household_id, item_id);
`,
  // 3 (1.2.0): product_map learns "auto" (a match carried from another chain), keeps what it needs to compare packs, and remembers where an auto match came from
  `
CREATE TABLE product_map_new (
  household_id INTEGER NOT NULL,
  item_id INTEGER NOT NULL,
  chain TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('confirmed', 'none', 'auto')),   -- auto = carried over from a confirmation at another chain
  code TEXT,
  item_type INTEGER,
  name TEXT,
  manufacturer TEXT,
  pack_amount REAL,
  pack_unit TEXT,
  weighted INTEGER,
  amount_kg REAL,
  source_chain TEXT,                  -- for auto: the chain whose confirmation it came from
  source_code TEXT,
  confirmed_by INTEGER,
  confirmed_at INTEGER NOT NULL,
  PRIMARY KEY (household_id, item_id, chain)
);
INSERT INTO product_map_new(household_id, item_id, chain, status, code, item_type, name, amount_kg, confirmed_by, confirmed_at)
  SELECT household_id, item_id, chain, status, code, item_type, name, amount_kg, confirmed_by, confirmed_at FROM product_map;
DROP TABLE product_map;
ALTER TABLE product_map_new RENAME TO product_map;
CREATE INDEX idx_product_map_item ON product_map(household_id, item_id);
`,
  // 4 (1.4.0): find a product by its barcode across the branches (the barcode-lookup capability)
  `
CREATE INDEX IF NOT EXISTS idx_branch_prices_code ON branch_prices(code);
`,
  // 5 (1.5.0): automatic matching. Products keep the chain's longer description (several chains cut ItemName at 20 characters), files already
  // read are read once more to fill it, matches say how they were made, guesses are kept for the one-tap review, and an AI's translations of
  // English item names are remembered (each English phrase is asked about once).
  `
ALTER TABLE branch_prices ADD COLUMN description TEXT NOT NULL DEFAULT '';
ALTER TABLE branch_prices ADD COLUMN desc_norm TEXT NOT NULL DEFAULT '';
ALTER TABLE branch_price_state ADD COLUMN desc_ok INTEGER NOT NULL DEFAULT 0;
ALTER TABLE product_map ADD COLUMN auto_via TEXT;      -- for auto: 'name' (the item's name is the product's name), 'barcode' or 'equivalent'
CREATE TABLE match_guess (                              -- the best candidate for an item at a chain that is not sure enough to apply by itself
  household_id INTEGER NOT NULL,
  item_id INTEGER NOT NULL,
  chain TEXT NOT NULL,
  stamp TEXT NOT NULL,                                  -- what the guess was made from (item name, branch files, translation); a different stamp means it is made again
  code TEXT,                                            -- NULL = looked, nothing close enough
  name TEXT,
  manufacturer TEXT,
  price REAL,
  score REAL,
  tier TEXT,                                            -- 'likely' (prefix of the name, or very close) or 'guess'
  alts TEXT,                                            -- JSON: the next best candidates
  searched TEXT,                                        -- the Hebrew the English name was searched as
  made_at INTEGER NOT NULL,
  PRIMARY KEY (household_id, item_id, chain)
);
CREATE TABLE translations (                             -- English phrase -> Hebrew search words, asked of an AI once and kept
  en TEXT PRIMARY KEY,
  he TEXT NOT NULL,
  source TEXT NOT NULL,
  made_at INTEGER NOT NULL
);
CREATE TABLE ai_settings (                              -- a person's own AI key for translating English item names (optional)
  user_id INTEGER PRIMARY KEY,
  provider TEXT NOT NULL,
  key_enc TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
`,
];

export default function register(ctx) {
  const { db } = ctx;
  const env = process.env, o = ctx.options; // o: tests (and PORTAL_URL_* variables) can point the portal clients at other servers
  const http = createHttp({ fetchImpl: o.fetch });
  const baseUrls = {
    ...(env.PORTAL_URL_SHUFERSAL && { shufersal: env.PORTAL_URL_SHUFERSAL }), ...(env.PORTAL_URL_SHARED && { shared: env.PORTAL_URL_SHARED }),
    ...(env.PORTAL_URL_CARREFOUR && { carrefour: env.PORTAL_URL_CARREFOUR }), ...o.baseUrls,
  };
  const portals = createPortals({ http, baseUrls });
  const dir = createDirectory({
    db, portals, http, citiesUrl: o.citiesUrl ?? env.PORTAL_CITIES_URL, delayMs: o.delayMs ?? 400,
    cacheDays: () => ctx.settings.get('branch_cache_days', 7),
  });
  const chains = makeChains(db);
  const prices = createPrices({ db, portals, chains, delayMs: o.priceDelayMs ?? o.delayMs ?? 400, refreshHours: () => ctx.settings.get('price_refresh_hours', 24), log: ctx.log });

  o.expose?.({ dir, chains, portals, prices }); // tests only
  const auto = createAutoMatcher({ db, prices, chains });
  const suggester = createSuggester({ db, prices });
  const guesser = createGuesser({ db, prices, suggester, auto });
  const ai = createAi({ db, secrets: ctx.secrets, options: ctx.options });
  compareRoutes(ctx, { chains, dir, prices, auto, suggester, guesser, ai, oldAfterDays: () => ctx.settings.get('old_after_days', 60) });
  // 'item-catalog': Add items offers the products of the chosen branches while you type (see catalog.js)
  // A person's own AI key for translating English item names (optional). The key is stored encrypted and never returned.
  ctx.routes.get('/ai/settings', async (req) => ({ settings: ai.settings(req.user.id), providers: ai.providers }));
  ctx.routes.put('/ai/settings', async (req, reply) => {
    const r = ai.save(req.user.id, req.body || {});
    return r.error ? reply.code(400).send({ error: r.error }) : r;
  });
  ctx.events.on('user.deleted', ({ userId }) => ai.forget(userId));
  ctx.provide('item-catalog', createCatalog({ db, prices, chains, core: ctx.core, auto }));
  portalRoutes(ctx, { chains, dir, portals });
  // 'barcode-lookup': what is this barcode, and what does it cost where you shop (used by the barcode-scan module)
  ctx.provide('barcode-lookup', createBarcodeLookup({ db, chains }));

  // Admin setting of this module (shown in the admin section of the web app).
  const adminSettings = () => ({ branchCacheDays: ctx.settings.get('branch_cache_days', 7), priceRefreshHours: ctx.settings.get('price_refresh_hours', 24), oldAfterDays: ctx.settings.get('old_after_days', 60) });
  ctx.routes.get('/admin/settings', { access: 'admin' }, async () => adminSettings());
  ctx.routes.put('/admin/settings', { access: 'admin' }, async (req, reply) => {
    const b = req.body || {};
    if (b.branchCacheDays !== undefined) {
      const n = Number(b.branchCacheDays);
      if (!Number.isInteger(n) || n < 1 || n > 90) return reply.code(400).send({ error: 'invalid_value' });
      ctx.settings.set('branch_cache_days', n); ctx.audit(req.user.id, 'settings', `branch_cache_days=${n}`);
    }
    // How often the portals are read again (a price itself never expires: it stays until a newer one arrives).
    if (b.priceRefreshHours !== undefined) {
      const n = Number(b.priceRefreshHours);
      if (!Number.isInteger(n) || n < 1 || n > 168) return reply.code(400).send({ error: 'invalid_value' });
      ctx.settings.set('price_refresh_hours', n); ctx.audit(req.user.id, 'settings', `price_refresh_hours=${n}`);
    }
    // After how many days without appearing in a price file a price is flagged old (it is never deleted).
    if (b.oldAfterDays !== undefined) {
      const n = Number(b.oldAfterDays);
      if (!Number.isInteger(n) || n < 7 || n > 365) return reply.code(400).send({ error: 'invalid_value' });
      ctx.settings.set('old_after_days', n); ctx.audit(req.user.id, 'settings', `old_after_days=${n}`);
    }
    return adminSettings();
  });

  // The 'price-source' capability: for now it only describes what this module can read. Live branch prices arrive in 1.4.0.
  ctx.provide('price-source', { id: 'price-compare', chains: () => chains.all().filter((c) => c.supported && c.enabled).map((c) => c.id), priceAt: (chain, storeId, code) => prices.priceAt(chain, storeId, code) });

  // Cleanup when the core removes things this module keeps notes about.
  const dropLists = (ids) => { const a = db.prepare('DELETE FROM list_compare_stores WHERE list_id = ?'), b = db.prepare('DELETE FROM list_compare_cities WHERE list_id = ?'); for (const id of ids) { a.run(id); b.run(id); } };
  ctx.events.on('list.deleted', ({ listId }) => dropLists([listId]));
  ctx.events.on('item.deleted', ({ itemId, householdId }) => db.prepare('DELETE FROM product_map WHERE household_id = ? AND item_id = ?').run(householdId, itemId));
  ctx.events.on('store.deleted', ({ storeId }) => db.prepare('DELETE FROM store_chain WHERE store_id = ?').run(storeId));
  ctx.events.on('household.deleted', ({ householdId, listIds = [], storeIds = [] }) => { dropLists(listIds); db.prepare('DELETE FROM product_map WHERE household_id = ?').run(householdId); const d = db.prepare('DELETE FROM store_chain WHERE store_id = ?'); for (const id of storeIds) d.run(id); });
}
